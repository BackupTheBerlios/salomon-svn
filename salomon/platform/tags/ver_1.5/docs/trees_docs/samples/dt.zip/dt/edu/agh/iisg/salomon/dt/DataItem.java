/**
 * 
 */
package edu.agh.iisg.salomon.dt;

import java.util.Vector;

/**
 * @author Lukasz Ostatek
 *
 */
public class DataItem {

    /**
     * 
     */
    private Vector<String> attributes=new Vector<String>();
    private String objective;
    private String name;
    
    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public Vector<String> getAttributes() {
        return attributes;
    }
    public String getAttributeAt(int index){
        return attributes.elementAt(index);
    }
    public void pushAttribute(String attrib){
        attributes.add(attrib);
    }
    public int getAttributeCount(){
        return attributes.size();
    }

    public DataItem(String data, int index) {
        String pom = data;
        int ttt;
        int indexNo=0;
        if((ttt=pom.indexOf(";"))>=0){
            this.setName(pom.substring(0,ttt).trim());
            pom=pom.substring(ttt+1);
        }
        while((ttt=pom.indexOf(";"))>=0){
            if(indexNo==index)
                this.setObjective(pom.substring(0,ttt).trim());
            else
                this.pushAttribute(pom.substring(0,ttt).trim());
            pom=pom.substring(ttt+1);
            indexNo++;
        }
        if(indexNo==index)
            this.setObjective(pom.trim());
        else
            this.pushAttribute(pom.trim());
    }
    public void print(){
        String message="--DataItem with objective="+objective+" name "+name+" and attributes ";
        for(String att:attributes)
            message+=att+", ";
        System.out.println(message);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
