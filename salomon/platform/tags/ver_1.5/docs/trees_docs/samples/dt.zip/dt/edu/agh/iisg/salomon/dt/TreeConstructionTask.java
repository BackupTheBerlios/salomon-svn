/**
 * 
 */
package edu.agh.iisg.salomon.dt;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 * @author Lukasz Ostatek
 */
public class TreeConstructionTask {

    /**
     * @param args
     */
    TreeItem root = null;

    Vector<TreeItem> treeElements = new Vector<TreeItem>();

    DataItem descriptions;

    Vector<Vector<String>> distinctClasses = new Vector<Vector<String>>();
    Vector<String> distinctObjectives = new Vector<String>();

    Vector<Boolean> used = new Vector<Boolean>();
    
    
    

    public TreeConstructionTask() {

    }

    public void loadFromFile(String filename, int objectiveIndex) {
        String thisLine;
        root = new TreeItem();
        treeElements.add(root);
        try {
            FileInputStream fin = new FileInputStream(filename);
            BufferedReader myInput = new BufferedReader(new InputStreamReader(
                    fin));
            if ((thisLine = myInput.readLine()) != null) {
                System.out.println(thisLine);
                descriptions = new DataItem(thisLine, objectiveIndex);
            }
            while ((thisLine = myInput.readLine()) != null) {
                System.out.println(thisLine);
                root.elements.add(new DataItem(thisLine, objectiveIndex));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i = 0; i < root.elements.elementAt(0).getAttributeCount(); i++) {
            distinctClasses.add(getDistinctClasses(i));
            used.add(false);
        }
        distinctObjectives.addAll(getDistinctClassesFromObjetives());
    }
    public boolean isAllHomogenous(){
        for(TreeItem ti:treeElements)
            if(ti.isLeaf())
                if(!ti.isHomogenous())
                    return false;
        return true;
    }
    public Vector<String> getDistinctClasses(int attributeIndex) {
        Vector<String> out = new Vector<String>();
        String pom = null;
        for (DataItem di : root.elements) {
            if (!out.contains((pom = di.getAttributeAt(attributeIndex))))
                out.add(pom);
        }
        return out;
    }
    public Vector<String> getDistinctClassesFromObjetives() {
        Vector<String> out = new Vector<String>();
        String pom = null;
        for (DataItem di : root.elements) {
            if (!out.contains((pom = di.getObjective())))
                out.add(pom);
        }
        return out;
    }
    public Vector<TreeItem> splitBy(Vector<TreeItem> vt, int attribute){
        Vector<TreeItem> out = new Vector<TreeItem>();
        for(TreeItem ti : vt){
            out.addAll(splitBy(ti,attribute));
        }
        return out;
    }
    public Vector<TreeItem> splitBy(TreeItem ti, int attribute){
        Vector<TreeItem> out = new Vector<TreeItem>();
        for(String klasa: distinctClasses.elementAt(attribute))
        {
            out.add(ti.subTreeItem(attribute,klasa));
        }
        return out;
    }
    
    public double calculateAverageEntropy(Vector<TreeItem> vt, int attribute) {
        double entropy = 0.0f;
        int totalSize = 0;
        for(TreeItem ti:vt )
        {
            totalSize+=ti.elements.size();
        }
        /*for (TreeItem ti : treeElements) {
            if (ti.isLeaf()) {
                entropy += ti.elements.size()
                        / totalSize
                        * ti.calculateEntropy(distinctClasses
                                .elementAt(attributeIndex));
            }
        }*/
        for(TreeItem ti: splitBy(vt,attribute)){
            if (ti.isLeaf()) {
                entropy += (((double)ti.elements.size())
                        / ((double)totalSize))
                        * ti.calculateEntropy(distinctObjectives);
            }
            else
            {
                System.out.println("Improper state");
            }
        }
        System.out.println("Average entropy for attrib="+descriptions.getAttributeAt(attribute)+" equals "+entropy);
        return entropy;
    }
    public Vector<TreeItem> getLeafs(){
        Vector<TreeItem> out = new Vector<TreeItem>();
        for(TreeItem ti: treeElements){
            if(ti.isLeaf())
                out.add(ti);
        }
        return out;
    }
    public void expandTree(int attribute){
        System.out.println("Expanding by attr:"+attribute);
        for(TreeItem ti: this.getLeafs()){
            if(!ti.isHomogenous())
            {   //nie rozwijam homogenicznych node'�w
                // TODO zeby w ogole ich nie brac przy wyliczaniu entropii 
                
                Vector<TreeItem> exps = splitBy(ti,attribute);
                for(TreeItem tiIn: exps){
                    tiIn.setParent(ti);
                    for(String elem: ti.getRoadMap())
                        tiIn.addToRoadMap(elem);
                    tiIn.addToRoadMap(descriptions.getAttributeAt(attribute));
                }
                treeElements.addAll(exps);
                ti.setLeaf(false);
            }
        }
        used.setElementAt(true,attribute);
    }
    public int getBestAvailableAttribute(){
        int bestNo=-1;
        double bestEntropy = 2;
        double tempEntropy;
        for(int i=0;i<used.size();i++){
            if(!used.elementAt(i))
                if((tempEntropy=calculateAverageEntropy(getLeafs(),i))<bestEntropy)
                {
                    bestEntropy=tempEntropy;
                    bestNo=i;
                }
        }
        System.out.println("BestAvailable ="+bestNo+" ("+bestEntropy+")");
        return bestNo;
    }
    public boolean anyAvailable(){
        for(Boolean us: used){
            if(!us) return true;
        }
        return false;
    }
    public void createTree(){
        System.out.println("----Tree creation start----");
        while((anyAvailable())&&(!isAllHomogenous())){
            System.out.println("----Tree creation - in loop----");
            expandTree(getBestAvailableAttribute());
        }
        System.out.println("----Tree creation end----");
        this.printLeavesOnly();
    }
    public void print(){
        System.out.println("----Tree start----");
        for(TreeItem ti : treeElements)
            ti.print();
        System.out.println("----Tree end----");
    }
    public void printLeavesOnly(){
        System.out.println("----Tree start----");
        for(TreeItem ti : treeElements)
            if(ti.isLeaf())
                ti.print();
        System.out.println("----Tree end----");
    }
}
